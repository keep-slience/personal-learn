Page({

  detail: function () {
    wx.navigateTo({
      url: '../share/content'
    })
  },
  /**
   * 页面的初始数据
   */

  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '免费讲座',
      
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    var that=this;
    if(res.from =="button"){
      console.log(res.target)
      if (res.target.id == "u93"){
        return {
          title:'93分享标题',
          path:'/pages/share/share'
        }
      }
      if (res.target.id== "u94"){
        return{
          title:'94分享标题',
          path:'/pages/share/share'
        }
      }
      if (res.target.id == "u95") {
        return {
          title: '95分享标题',
          path: '/pages/share/share'
        }
      }
      if (res.target.id == "u96") {
        return {
          title: '96分享标题',
          path: '/pages/share/share'
        }
      }
      if (res.target.id == "u97") {
        return {
          title: '97分享标题',
          path: '/pages/share/share'
        }
      }
      if (res.target.id == "u98") {
        return {
          title: '98分享标题',
          path: '/pages/share/share'
        }
      }
      if (res.target.id == "u99") {
        return {
          title: '99分享标题',
          path: '/pages/share/share'
        }
      }     
    }
    else{
      return{
        title:'右上角分享',
        path:'/pages/share/share'
      }
    }
  }
})