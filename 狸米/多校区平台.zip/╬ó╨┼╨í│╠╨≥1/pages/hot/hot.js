// pages/hot/hot.js
Page({

  /**
   * 页面的初始数据
   */
  
  data: {
  arr:[
{ src: "../../images/热门课程_1/u542.png", text: "一年级"}, 
{ src: "../../images/热门课程_1/u543.png", text: "二年级"}, 
{ src: "../../images/热门课程_1/u543.png", text: "三年级"}, 
{ src: "../../images/热门课程_1/u543.png", text: "四年级"}, 
{ src: "../../images/热门课程_1/u543.png", text: "五年级"},
{ src: "../../images/热门课程_1/u542.png", text: "六年级", six:"rotate(180deg)"},
  ],
bind1:true,
bind2:false
  },
 
  maintap1:function(e){
  console.log("点击触发1");
  var tap=this.data.bind1;
  if (this.data.bind1 ==false)
  this.setData({
    bind1:true,
    bind2:false
  })
  },

  maintap2:function(e){
    console.log("点击触发2");
    var tap = this.data.bind2;
    if (this.data.bind2 == false)
      this.setData({
        bind1: false,
        bind2: true
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '热门课程',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (e) {
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  pullDownRefresh: function (e) {
    console.log("下拉刷新....")
    this.onLoad()
  },

  pullUpLoad: function (e) {
    this.setData({
      page: this.data.page + 1
    })

    console.log("上拉拉加载更多...." + this.data.page)

    this.getDataFromServer(this.data.page)
  },
  

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  console.log('hi')
  if (this.data.loading) return;
  this.setData({loading:true});
  wx.showLoading({
    title: '加载中',
  })
  wx.showNavigationBarLoading();
  wx.request({
    url: '',
    data:{},
    method:'GET',
    success:function(res){
    //success
    },
    fail:function(){
    
    //fail
    },
    complete:function(){
      //complete
      wx.hideNavigationBarLoading()
      wx.hideLoading()
    }
  })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  return{
    title:'分享标题',
    desc:'分享描述',
    path:'pages/hot/hot?id=123'
  }
  }
})