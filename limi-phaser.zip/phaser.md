# phaser说明
* 没弄明白phaser3，现在用phaser2.6.2版本，cdn：https://cdn.bootcss.com/phaser/2.6.2/phaser.min.js
* phaser的属性命名为驼峰式：fontSize等，支持text内直接输入空格
# 实现功能
* UI布局，屏幕适配
* 开始做题按钮和返回以及返回图标的场景切换，目前为内部stage的切换
* 直接写成横版，无论重力方向如何