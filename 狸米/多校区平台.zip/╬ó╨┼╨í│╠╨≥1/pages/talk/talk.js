// pages/talk/talk.js
Page({
  onShareAppMessage: function () {
return{
  title:'分享标题',
  desc:'分享描述',
  path:'/pages/talk/talk?id=123'
}
  },

  one: function () {
    wx.navigateTo({
      url: '../share/share'
    })
  },

  two:function(){
wx.navigateTo({
  url: '../share/share'
})
  },

  three: function () {
    wx.navigateTo({
      url: '../share/share'
    })
  },

  four: function () {
    wx.navigateTo({
      url: '../share/share'
    })
  },

  /**
   * 页面的初始数据
   */
  
  data: {
    arr: [
      { src: "../../images/专家访谈_1/u498.png" },
      { src: "../../images/专家访谈_1/u498.png" },
      { src: "../../images/专家访谈_1/u498.png" },

  ],
  tip:[
    { src: "../../images/收入明细/u307.png", text:"讲座"},
    { src: "../../images/收入明细/u307.png", text:"学生心理"},
    { src: "../../images/收入明细/u338.png", text:"学习方法"},
  ],
  column:[
    { bg: "../../images/可分享资源/u73.png", cov: "../../images/可分享资源/u74.png", title:"免费讲座  |  没错！就是这三类父母毁了孩子！",tap:"one"},
    { bg: "../../images/可分享资源/u73.png", cov: "../../images/可分享资源/u74.png", title:"家长学院  | 中考老师判卷只要30秒！你说孩子写字好看到底重要不重要！", tap:"two"},
    { bg: "../../images/可分享资源/u73.png", cov: "../../images/可分享资源/u74.png", title:"精彩文章  |  人贩子的告白：天底下就没有我拐不走的孩子！", tap:"three" },
    { bg: "../../images/可分享资源/u73.png", cov: "../../images/可分享资源/u74.png", title:"育儿心经  |  35岁以后，这样的女人越活越气质", tap:"four" }
  ]
  },

  ad:function(){
   wx.navigateTo({
     url: '../share/share',
   })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '专家访谈',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  }) 